<?php
  header("location: Views/home.php");
?>